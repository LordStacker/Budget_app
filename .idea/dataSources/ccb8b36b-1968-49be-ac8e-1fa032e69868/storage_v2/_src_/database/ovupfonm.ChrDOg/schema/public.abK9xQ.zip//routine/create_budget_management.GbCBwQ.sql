create function create_budget_management() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO "semester_project"."budget_management" ("user_id", "start_amount", "current_amount", "iteminfo_id", "prt_id")
    VALUES (NEW."user_id", 0.00, 0.00, 0, 0);  -- Default value for prt_id is 0
    RETURN NEW;
END;
$$;

alter function create_budget_management() owner to ovupfonm;

