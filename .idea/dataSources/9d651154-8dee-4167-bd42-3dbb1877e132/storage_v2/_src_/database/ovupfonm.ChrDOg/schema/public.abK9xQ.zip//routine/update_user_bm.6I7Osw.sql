create function update_user_bm() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO "semester_project"."user_bm" ("user_id", "bm_id")
    VALUES (NEW."user_id", NEW."user_id");
    RETURN NEW;
END;
$$;

alter function update_user_bm() owner to ovupfonm;

